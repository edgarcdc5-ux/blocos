package com.cleaneditor.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

enum class AppTheme(val label: String) { SUNSET("Sunset (padrão)"), CLARO("Claro") }

@Immutable
data class Palette(
    val isDark: Boolean,
    val background: Color,
    val glow1: Color,
    val glow2: Color,
    val surface: Color,
    val surfaceStrong: Color,
    val border: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val accentText: Color,
    val gradient: List<Color>,
    val high: Color,
    val medium: Color,
    val low: Color,
    val codeHeading: Color,
    val codeBullet: Color,
    val codeString: Color,
    val codeNumber: Color,
) {
    val brush: Brush get() = Brush.linearGradient(gradient)
}

val SunsetPalette = Palette(
    isDark = true,
    background = Color(0xFF120D0B),
    glow1 = Color(0x55F97316),
    glow2 = Color(0x44EC4899),
    surface = Color(0x1FFFFFFF),
    surfaceStrong = Color(0x2EFFFFFF),
    border = Color(0x26FFFFFF),
    text = Color(0xFFFFF7ED),
    muted = Color(0xFFB8A79C),
    accent = Color(0xFFF97316),
    accentText = Color.White,
    gradient = listOf(Color(0xFFF59E0B), Color(0xFFF97316), Color(0xFFEC4899)),
    high = Color(0xFFFB7185),
    medium = Color(0xFFFBBF24),
    low = Color(0xFF34D399),
    codeHeading = Color(0xFFFDBA74),
    codeBullet = Color(0xFFF472B6),
    codeString = Color(0xFFFDE68A),
    codeNumber = Color(0xFFC4B5FD),
)

val ClaroPalette = Palette(
    isDark = false,
    background = Color(0xFFF6F7F9),
    glow1 = Color(0x3314B8A6),
    glow2 = Color(0x2238BDF8),
    surface = Color(0xCCFFFFFF),
    surfaceStrong = Color(0xFFFFFFFF),
    border = Color(0xFFE5E7EB),
    text = Color(0xFF0F172A),
    muted = Color(0xFF64748B),
    accent = Color(0xFF10B981),
    accentText = Color.White,
    gradient = listOf(Color(0xFF10B981), Color(0xFF14B8A6)),
    high = Color(0xFFF43F5E),
    medium = Color(0xFFF59E0B),
    low = Color(0xFF10B981),
    codeHeading = Color(0xFF0F766E),
    codeBullet = Color(0xFF4F46E5),
    codeString = Color(0xFFB45309),
    codeNumber = Color(0xFF7C3AED),
)

val LocalPalette = staticCompositionLocalOf { SunsetPalette }

@Composable
fun CleanEditorTheme(theme: AppTheme, content: @Composable () -> Unit) {
    val p = if (theme == AppTheme.CLARO) ClaroPalette else SunsetPalette
    val scheme = if (p.isDark) darkColorScheme(
        primary = p.accent, onPrimary = p.accentText, background = p.background,
        surface = Color(0xFF1C1512), onSurface = p.text, onBackground = p.text,
        surfaceVariant = Color(0xFF2A201B), onSurfaceVariant = p.muted,
    ) else lightColorScheme(
        primary = p.accent, onPrimary = p.accentText, background = p.background,
        surface = Color.White, onSurface = p.text, onBackground = p.text,
        surfaceVariant = Color(0xFFF1F5F9), onSurfaceVariant = p.muted,
    )
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
