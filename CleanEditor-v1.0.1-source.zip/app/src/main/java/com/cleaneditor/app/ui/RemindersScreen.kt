package com.cleaneditor.app.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cleaneditor.app.AppViewModel
import com.cleaneditor.app.data.Priority
import com.cleaneditor.app.data.Reminder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private val ptBR = Locale("pt", "BR")
private fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }
    val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

@Composable
fun RemindersScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Todos") }
    var day by remember { mutableStateOf<Long?>(null) }
    var editing by remember { mutableStateOf<Reminder?>(null) }
    var creating by remember { mutableStateOf(false) }

    val q = query.trim().lowercase()
    val shown = vm.reminders.filter { q.isEmpty() || it.title.lowercase().contains(q) || it.content.lowercase().contains(q) }
        .filter { when (filter) { "Pendentes" -> !it.done; "Concluídos" -> it.done; else -> true } }
        .filter { r -> day == null || sameDay(r.timeMillis, day!!) || (r.repeatDaily && !r.done) }
        .sortedWith(compareBy<Reminder> { it.done }.thenBy { it.timeMillis })

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 170.dp)
        ) {
            item { ScreenTitle("Lembretes") }
            item { WeekStrip(day) { day = if (day != null && sameDay(day!!, it)) null else it } }
            item { SearchField(query, "Pesquisar lembretes", { query = it }) }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Todos", "Pendentes", "Concluídos").forEach { Pill(it, filter == it) { filter = it } }
                }
            }
            if (shown.isEmpty()) item { EmptyState(Icons.Outlined.NotificationsNone, "Nenhum lembrete", "Toque em + para criar") }
            items(shown, key = { it.id }) { r ->
                ReminderCard(r, onToggle = { vm.upsertReminder(r.copy(done = !r.done)) }, onClick = { editing = r })
            }
        }
        Box(
            Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 22.dp, bottom = 96.dp)
                .shadow(16.dp, CircleShape).size(60.dp).clip(CircleShape).background(p.brush).clickable { creating = true },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Outlined.Add, "Novo lembrete", tint = Color.White, modifier = Modifier.size(30.dp)) }
    }

    if (creating || editing != null) {
        ReminderDialog(
            initial = editing,
            onDismiss = { creating = false; editing = null },
            onSave = { vm.upsertReminder(it); creating = false; editing = null },
            onDelete = { vm.deleteReminder(it); editing = null }
        )
    }
}

@Composable
private fun WeekStrip(selected: Long?, onPick: (Long) -> Unit) {
    val p = LocalPalette.current
    val names = listOf("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in -1..12) {
            val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, i) }
            val t = c.timeInMillis
            val active = selected != null && sameDay(selected, t)
            val today = i == 0
            val shape = RoundedCornerShape(18.dp)
            val base = Modifier.width(54.dp).clip(shape)
            val m = if (active) base.background(p.brush) else base.background(p.surface).border(1.dp, if (today) p.accent else p.border, shape)
            Column(m.clickable { onPick(t) }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(names[c.get(Calendar.DAY_OF_WEEK) - 1], color = if (active) Color.White else p.muted, fontSize = 12.sp)
                Text(c.get(Calendar.DAY_OF_MONTH).toString(), color = if (active) Color.White else p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ReminderCard(r: Reminder, onToggle: () -> Unit, onClick: () -> Unit) {
    val p = LocalPalette.current
    val color = when (r.priority) { Priority.ALTA -> p.high; Priority.MEDIA -> p.medium; Priority.BAIXA -> p.low }
    val fmt = SimpleDateFormat("dd/MM • HH:mm", ptBR)
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick, padding = PaddingValues(0.dp)) {
        Row(Modifier.height(androidx.compose.foundation.layout.IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(color))
            Column(Modifier.weight(1f).padding(14.dp)) {
                Text(
                    r.priority.label, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.15f)).padding(horizontal = 8.dp, vertical = 2.dp)
                )
                Spacer(Modifier.height(6.dp))
                Text(r.title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    textDecoration = if (r.done) TextDecoration.LineThrough else null)
                if (r.content.isNotBlank()) Text(r.content, color = p.muted, fontSize = 13.sp, maxLines = 2)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Alarm, null, tint = p.muted, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        (if (r.repeatDaily) SimpleDateFormat("HH:mm", ptBR).format(r.timeMillis) + " • diário" else fmt.format(r.timeMillis)) + " • " + r.category,
                        color = p.muted, fontSize = 12.sp
                    )
                }
            }
            val shape = CircleShape
            Box(
                Modifier.padding(end = 14.dp).size(28.dp).clip(shape)
                    .let { if (r.done) it.background(p.brush) else it.border(2.dp, p.muted, shape) }
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) { if (r.done) Icon(Icons.Outlined.Check, "Concluído", tint = Color.White, modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
private fun ReminderDialog(initial: Reminder?, onDismiss: () -> Unit, onSave: (Reminder) -> Unit, onDelete: (Reminder) -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var content by remember { mutableStateOf(initial?.content ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "Geral") }
    var repeat by remember { mutableStateOf(initial?.repeatDaily ?: false) }
    var priority by remember { mutableStateOf(initial?.priority ?: Priority.MEDIA) }
    var time by remember {
        mutableLongStateOf(initial?.timeMillis ?: Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 8); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis)
    }
    val cal = Calendar.getInstance().apply { timeInMillis = time }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Novo lembrete" else "Editar lembrete") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Título") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(content, { content = it }, label = { Text("Conteúdo") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(category, { category = it }, label = { Text("Categoria") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(SimpleDateFormat("dd/MM/yyyy", ptBR).format(time), false) {
                        DatePickerDialog(ctx, { _, y, m, d ->
                            time = Calendar.getInstance().apply { timeInMillis = time; set(y, m, d) }.timeInMillis
                        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                    }
                    Pill(SimpleDateFormat("HH:mm", ptBR).format(time), false) {
                        TimePickerDialog(ctx, { _, h, min ->
                            time = Calendar.getInstance().apply { timeInMillis = time; set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0) }.timeInMillis
                        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
                    }
                }
                Text("Prioridade", color = p.muted, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Priority.entries.forEach { pr -> Pill(pr.label, priority == pr) { priority = pr } }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Repetir todo dia", modifier = Modifier.weight(1f))
                    Switch(repeat, { repeat = it })
                }
            }
        },
        confirmButton = {
            TextButton({
                if (title.isNotBlank()) onSave(
                    Reminder(initial?.id ?: System.currentTimeMillis(), title.trim(), content.trim(), time, repeat, priority, category.ifBlank { "Geral" }, initial?.done ?: false)
                )
            }) { Text("Salvar") }
        },
        dismissButton = {
            Row {
                if (initial != null) TextButton({ onDelete(initial) }) { Text("Excluir", color = p.high) }
                TextButton(onDismiss) { Text("Cancelar") }
            }
        }
    )
}
