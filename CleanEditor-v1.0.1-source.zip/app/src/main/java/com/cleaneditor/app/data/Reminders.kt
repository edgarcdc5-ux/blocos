package com.cleaneditor.app.data

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.cleaneditor.app.MainActivity
import com.cleaneditor.app.R
import org.json.JSONArray
import org.json.JSONObject

enum class Priority(val label: String) { ALTA("Alta"), MEDIA("Média"), BAIXA("Baixa") }

data class Reminder(
    val id: Long,
    val title: String,
    val content: String,
    val timeMillis: Long,
    val repeatDaily: Boolean,
    val priority: Priority,
    val category: String,
    val done: Boolean,
)

class ReminderStore(private val context: Context) {
    private val sp = context.getSharedPreferences("cleaneditor_reminders", Context.MODE_PRIVATE)

    fun all(): List<Reminder> {
        val arr = JSONArray(sp.getString("items", "[]"))
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Reminder(
                id = o.getLong("id"),
                title = o.getString("title"),
                content = o.optString("content"),
                timeMillis = o.getLong("time"),
                repeatDaily = o.optBoolean("repeat"),
                priority = runCatching { Priority.valueOf(o.optString("priority")) }.getOrDefault(Priority.MEDIA),
                category = o.optString("category", "Geral"),
                done = o.optBoolean("done"),
            )
        }
    }

    fun saveAll(list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("content", it.content)
                    .put("time", it.timeMillis).put("repeat", it.repeatDaily).put("priority", it.priority.name)
                    .put("category", it.category).put("done", it.done)
            )
        }
        sp.edit().putString("items", arr.toString()).apply()
    }

    fun upsert(r: Reminder) {
        val list = all().filter { it.id != r.id } + r
        saveAll(list)
        if (r.done) ReminderScheduler.cancel(context, r) else ReminderScheduler.schedule(context, r)
    }

    fun delete(r: Reminder) {
        saveAll(all().filter { it.id != r.id })
        ReminderScheduler.cancel(context, r)
    }
}

object ReminderScheduler {
    const val CHANNEL = "lembretes"

    private fun pending(context: Context, id: Long): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("id", id)
        return PendingIntent.getBroadcast(
            context, id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, r: Reminder) {
        var time = r.timeMillis
        val now = System.currentTimeMillis()
        if (time <= now) {
            if (!r.repeatDaily) return
            while (time <= now) time += AlarmManager.INTERVAL_DAY
        }
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = pending(context, r.id)
        val exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        if (exactAllowed) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
        }
    }

    fun cancel(context: Context, r: Reminder) {
        context.getSystemService(AlarmManager::class.java)?.cancel(pending(context, r.id))
    }

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(
                NotificationChannel(CHANNEL, "Lembretes", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1)
        val store = ReminderStore(context)
        val r = store.all().firstOrNull { it.id == id } ?: return
        if (r.done) return
        ReminderScheduler.ensureChannel(context)
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java).putExtra("tab", "lembretes"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, ReminderScheduler.CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(r.title)
            .setContentText(r.content.ifBlank { "Lembrete • ${r.category}" })
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(r.id.toInt(), n) }
        if (r.repeatDaily) {
            val next = r.copy(timeMillis = r.timeMillis + AlarmManager.INTERVAL_DAY)
            store.upsert(next)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        ReminderStore(context).all().filter { !it.done }.forEach { ReminderScheduler.schedule(context, it) }
    }
}
