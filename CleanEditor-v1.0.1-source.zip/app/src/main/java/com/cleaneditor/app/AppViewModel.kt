package com.cleaneditor.app

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.AndroidViewModel
import com.cleaneditor.app.data.Prefs
import com.cleaneditor.app.data.RecentFile
import com.cleaneditor.app.data.Reminder
import com.cleaneditor.app.data.ReminderStore
import com.cleaneditor.app.ui.AppTheme
import java.io.File

enum class Tab(val label: String) { INICIO("Início"), ARQUIVOS("Arquivos"), LEMBRETES("Lembretes"), IA("IA"), AJUSTES("Ajustes") }

class EditorDoc(val uri: String, name: String, text: String) {
    var name by mutableStateOf(name)
    var value by mutableStateOf(TextFieldValue(text))
    var savedText by mutableStateOf(text)
    val undo = ArrayDeque<String>()
    val redo = ArrayDeque<String>()
    var lastPush = 0L
    var text: String
        get() = value.text
        set(v) { value = TextFieldValue(v, TextRange(value.selection.end.coerceIn(0, v.length))) }
    val dirty: Boolean get() = text != savedText
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    val prefs = Prefs(app)
    private val reminderStore = ReminderStore(app)

    var tab by mutableStateOf(Tab.INICIO)
    var editorOpen by mutableStateOf(false)
    var theme by mutableStateOf(prefs.theme)
    var fontSize by mutableStateOf(prefs.fontSize)
    var wrap by mutableStateOf(prefs.wrap)
    var lineNumbers by mutableStateOf(prefs.lineNumbers)
    var userName by mutableStateOf(prefs.userName)
    var message by mutableStateOf<String?>(null)

    val recents = mutableStateListOf<RecentFile>().apply { addAll(prefs.recents()) }
    val docs = mutableStateListOf<EditorDoc>()
    var current by mutableStateOf(-1)
    val reminders = mutableStateListOf<Reminder>().apply { addAll(reminderStore.all()) }

    val currentDoc: EditorDoc? get() = docs.getOrNull(current)

    private val docsDir: File get() = File(ctx.filesDir, "documentos").apply { mkdirs() }

    fun localFiles(): List<File> = docsDir.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun setThemeChoice(t: AppTheme) { theme = t; prefs.theme = t }
    fun setFont(v: Int) { fontSize = v; prefs.fontSize = v }
    fun setWrapChoice(v: Boolean) { wrap = v; prefs.wrap = v }
    fun setLineNumbersChoice(v: Boolean) { lineNumbers = v; prefs.lineNumbers = v }
    fun setName(v: String) { userName = v; prefs.userName = v }

    fun newDocument(ext: String = "md") {
        var i = 1
        var f: File
        do { f = File(docsDir, "novo-$i.$ext"); i++ } while (f.exists())
        f.writeText("")
        open(Uri.fromFile(f))
    }

    fun displayName(uri: Uri): String {
        if (uri.scheme == "file") return uri.lastPathSegment ?: "arquivo"
        return runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment ?: "arquivo"
    }

    fun open(uri: Uri, persist: Boolean = false) {
        val key = uri.toString()
        val existing = docs.indexOfFirst { it.uri == key }
        if (existing >= 0) { current = existing; editorOpen = true; return }
        if (persist) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
        }
        val text = runCatching {
            if (uri.scheme == "file") File(uri.path!!).readText()
            else ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
        }.getOrElse {
            message = "Não foi possível abrir o arquivo"
            return
        }
        val name = displayName(uri)
        docs.add(EditorDoc(key, name, text))
        current = docs.lastIndex
        editorOpen = true
        touchRecent(key, name)
    }

    private fun touchRecent(uri: String, name: String) {
        val fav = recents.firstOrNull { it.uri == uri }?.favorite ?: false
        recents.removeAll { it.uri == uri }
        recents.add(0, RecentFile(uri, name, System.currentTimeMillis(), fav))
        prefs.saveRecents(recents)
    }

    fun toggleFavorite(uri: String, name: String) {
        val i = recents.indexOfFirst { it.uri == uri }
        if (i >= 0) recents[i] = recents[i].copy(favorite = !recents[i].favorite)
        else recents.add(RecentFile(uri, name, System.currentTimeMillis(), true))
        prefs.saveRecents(recents)
    }

    fun removeRecent(uri: String) { recents.removeAll { it.uri == uri }; prefs.saveRecents(recents) }

    fun deleteLocal(file: File) {
        val key = Uri.fromFile(file).toString()
        file.delete()
        removeRecent(key)
        val i = docs.indexOfFirst { it.uri == key }
        if (i >= 0) closeDoc(i)
    }

    fun edit(doc: EditorDoc, newValue: TextFieldValue) {
        if (newValue.text != doc.text) {
            val now = System.currentTimeMillis()
            if (now - doc.lastPush > 700 || doc.undo.isEmpty()) {
                doc.undo.addLast(doc.text)
                if (doc.undo.size > 200) doc.undo.removeFirst()
                doc.lastPush = now
            }
            doc.redo.clear()
        }
        doc.value = newValue
    }

    fun wrapSelection(doc: EditorDoc, before: String, after: String = "") {
        val t = doc.text
        val s = doc.value.selection.min.coerceIn(0, t.length)
        val e = doc.value.selection.max.coerceIn(0, t.length)
        val newText = t.substring(0, s) + before + t.substring(s, e) + after + t.substring(e)
        pushUndo(doc)
        doc.value = TextFieldValue(newText, TextRange(e + before.length))
    }

    fun linePrefix(doc: EditorDoc, prefix: String) {
        val t = doc.text
        val s = doc.value.selection.min.coerceIn(0, t.length)
        val lineStart = if (s == 0) 0 else t.lastIndexOf('\n', s - 1) + 1
        pushUndo(doc)
        doc.value = TextFieldValue(t.substring(0, lineStart) + prefix + t.substring(lineStart), TextRange(s + prefix.length))
    }

    fun undo(doc: EditorDoc) {
        val prev = doc.undo.removeLastOrNull() ?: return
        doc.redo.addLast(doc.text); doc.text = prev
    }

    fun redo(doc: EditorDoc) {
        val next = doc.redo.removeLastOrNull() ?: return
        doc.undo.addLast(doc.text); doc.text = next
    }

    private fun pushUndo(doc: EditorDoc) {
        doc.undo.addLast(doc.text); doc.redo.clear(); doc.lastPush = 0
    }

    fun replaceText(doc: EditorDoc, newText: String) {
        pushUndo(doc); doc.text = newText
    }

    fun save(doc: EditorDoc) {
        val uri = Uri.parse(doc.uri)
        val ok = runCatching {
            if (uri.scheme == "file") File(uri.path!!).writeText(doc.text)
            else ctx.contentResolver.openOutputStream(uri, "wt")!!.bufferedWriter().use { it.write(doc.text) }
        }.isSuccess
        if (ok) { doc.savedText = doc.text; message = "Salvo: ${doc.name}" } else message = "Falha ao salvar ${doc.name}"
    }

    fun saveAs(doc: EditorDoc, target: Uri) {
        val ok = runCatching {
            ctx.contentResolver.openOutputStream(target, "wt")!!.bufferedWriter().use { it.write(doc.text) }
        }.isSuccess
        if (ok) message = "Cópia salva em ${displayName(target)}" else message = "Falha ao exportar"
    }

    fun renameLocal(doc: EditorDoc, newName: String) {
        val uri = Uri.parse(doc.uri)
        if (uri.scheme != "file" || newName.isBlank()) return
        val src = File(uri.path!!)
        val dst = File(src.parentFile, newName.trim())
        if (dst.exists() || !src.renameTo(dst)) { message = "Não foi possível renomear"; return }
        val i = docs.indexOf(doc)
        val moved = EditorDoc(Uri.fromFile(dst).toString(), dst.name, doc.text).also { it.savedText = doc.savedText }
        docs[i] = moved
        removeRecent(doc.uri)
        touchRecent(moved.uri, moved.name)
    }

    fun closeDoc(index: Int) {
        if (index !in docs.indices) return
        docs.removeAt(index)
        current = if (docs.isEmpty()) -1 else index.coerceAtMost(docs.lastIndex)
        if (docs.isEmpty()) editorOpen = false
    }

    fun upsertReminder(r: Reminder) {
        reminderStore.upsert(r)
        reminders.clear(); reminders.addAll(reminderStore.all())
    }

    fun deleteReminder(r: Reminder) {
        reminderStore.delete(r)
        reminders.clear(); reminders.addAll(reminderStore.all())
    }
}
