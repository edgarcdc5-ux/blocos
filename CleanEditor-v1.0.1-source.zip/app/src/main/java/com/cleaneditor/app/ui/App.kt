package com.cleaneditor.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cleaneditor.app.AppViewModel
import com.cleaneditor.app.Tab

@Composable
fun CleanEditorApp(vm: AppViewModel) {
    CleanEditorTheme(vm.theme) {
        val snack = remember { SnackbarHostState() }
        LaunchedEffect(vm.message) {
            vm.message?.let { snack.showSnackbar(it); vm.message = null }
        }
        AuroraBackground {
            Box(Modifier.fillMaxSize().statusBarsPadding()) {
                if (vm.editorOpen && vm.currentDoc != null) {
                    BackHandler { vm.editorOpen = false }
                    EditorScreen(vm)
                } else {
                    BackHandler(enabled = vm.tab != Tab.INICIO) { vm.tab = Tab.INICIO }
                    AnimatedContent(targetState = vm.tab, label = "tab") { t ->
                        Box(Modifier.fillMaxSize()) {
                            when (t) {
                                Tab.INICIO -> HomeScreen(vm)
                                Tab.ARQUIVOS -> FilesScreen(vm)
                                Tab.LEMBRETES -> RemindersScreen(vm)
                                Tab.IA -> ToolsScreen(vm)
                                Tab.AJUSTES -> SettingsScreen(vm)
                            }
                        }
                    }
                    FloatingNav(vm.tab, { vm.tab = it }, Modifier.align(Alignment.BottomCenter))
                }
                SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).padding(bottom = 96.dp))
            }
        }
    }
}

private val tabIcons: Map<Tab, ImageVector> = mapOf(
    Tab.INICIO to Icons.Outlined.Home,
    Tab.ARQUIVOS to Icons.Outlined.Folder,
    Tab.LEMBRETES to Icons.Outlined.NotificationsNone,
    Tab.IA to Icons.Outlined.AutoAwesome,
    Tab.AJUSTES to Icons.Outlined.Settings,
)

@Composable
fun FloatingNav(selected: Tab, onSelect: (Tab) -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(32.dp)
    val bar = if (p.isDark) Color(0xE61C1512) else Color(0xF2FFFFFF)
    Row(
        modifier.navigationBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp).fillMaxWidth()
            .shadow(18.dp, shape).clip(shape).background(bar).border(1.dp, p.border, shape).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Tab.entries.forEach { t ->
            val active = t == selected
            val m = Modifier.weight(1f).clip(RoundedCornerShape(26.dp))
                .let { if (active) it.background(p.brush) else it }
                .clickable { onSelect(t) }.padding(vertical = 8.dp)
            Column(m, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(tabIcons.getValue(t), t.label, tint = if (active) Color.White else p.muted, modifier = Modifier.size(22.dp))
                Text(
                    t.label, fontSize = 11.sp, maxLines = 1,
                    color = if (active) Color.White else p.muted,
                    fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}
