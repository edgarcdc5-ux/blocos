package com.cleaneditor.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.DataObject
import androidx.compose.material.icons.outlined.FormatListNumbered
import androidx.compose.material.icons.outlined.Insights
import androidx.compose.material.icons.outlined.SortByAlpha
import androidx.compose.material.icons.outlined.TextFields
import androidx.compose.material.icons.outlined.Toc
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cleaneditor.app.AppViewModel
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

private data class Tool(val title: String, val desc: String, val icon: ImageVector, val run: (String) -> String?)

object TextTools {
    fun formatJson(t: String): String? = runCatching {
        when (val v = JSONTokener(t.trim()).nextValue()) {
            is JSONObject -> v.toString(2)
            is JSONArray -> v.toString(2)
            else -> null
        }
    }.getOrNull()

    fun sortLines(t: String) = t.lines().sortedWith(String.CASE_INSENSITIVE_ORDER).joinToString("\n")
    fun dedupe(t: String) = t.lines().distinct().joinToString("\n")
    fun removeBlank(t: String) = t.lines().filter { it.isNotBlank() }.joinToString("\n")
    fun trimSpaces(t: String) = t.lines().joinToString("\n") { it.trimEnd().replace(Regex(" {2,}"), " ") }
    fun capitalizeSentences(t: String): String {
        val sb = StringBuilder(t.length)
        var cap = true
        for (ch in t) {
            if (cap && ch.isLetter()) { sb.append(ch.uppercaseChar()); cap = false } else sb.append(ch)
            if (ch == '.' || ch == '!' || ch == '?' || ch == '\n') cap = true
        }
        return sb.toString()
    }
    fun numberLines(t: String) = t.lines().mapIndexed { i, l -> "${i + 1}. $l" }.joinToString("\n")
    fun toc(t: String): String {
        val heads = t.lines().filter { it.trimStart().startsWith("#") }
        if (heads.isEmpty()) return t
        val list = heads.joinToString("\n") { h ->
            val level = h.trimStart().takeWhile { it == '#' }.length
            "  ".repeat((level - 1).coerceAtLeast(0)) + "- " + h.trimStart().trimStart('#').trim()
        }
        return "## Sumário\n$list\n\n$t"
    }
    fun stats(t: String): String {
        val words = t.split(Regex("\\s+")).count { it.isNotBlank() }
        val minutes = (words / 200.0).let { if (it < 1) "menos de 1" else String.format("%.0f", it) }
        return "${t.length} caracteres • $words palavras • ${t.lines().size} linhas • leitura: $minutes min"
    }
}

@Composable
fun ToolsScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    var last by remember { mutableStateOf<String?>(null) }
    val doc = vm.currentDoc
    val tools = listOf(
        Tool("Formatar JSON", "Indenta e valida o JSON", Icons.Outlined.DataObject) { TextTools.formatJson(it) },
        Tool("Limpar espaços", "Remove espaços duplos e no fim das linhas", Icons.Outlined.CleaningServices) { TextTools.trimSpaces(it) },
        Tool("Remover linhas vazias", "Deixa o texto compacto", Icons.Outlined.CleaningServices) { TextTools.removeBlank(it) },
        Tool("Remover duplicadas", "Mantém só a primeira de cada linha", Icons.Outlined.FormatListNumbered) { TextTools.dedupe(it) },
        Tool("Ordenar linhas A-Z", "Ordem alfabética", Icons.Outlined.SortByAlpha) { TextTools.sortLines(it) },
        Tool("Maiúscula nas frases", "Corrige o início de cada frase", Icons.Outlined.TextFields) { TextTools.capitalizeSentences(it) },
        Tool("Numerar linhas", "Adiciona 1., 2., 3.…", Icons.Outlined.FormatListNumbered) { TextTools.numberLines(it) },
        Tool("Gerar sumário", "Índice a partir dos títulos Markdown", Icons.Outlined.Toc) { TextTools.toc(it) },
    )

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp)
    ) {
        item { ScreenTitle("Assistente", "Ferramentas inteligentes de texto, funcionam offline") }
        item {
            GradientCard(Modifier.fillMaxWidth()) {
                Text("Documento", color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                Text(doc?.name ?: "Nenhum documento aberto", color = androidx.compose.ui.graphics.Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (doc != null) Text(TextTools.stats(doc.text), color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
        }
        if (vm.docs.size > 1) item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                vm.docs.forEachIndexed { i, d -> Pill(d.name, i == vm.current) { vm.current = i } }
            }
        }
        if (doc == null) {
            item { EmptyState(Icons.Outlined.AutoAwesome, "Abra um documento", "As ferramentas agem sobre o documento aberto no Editor") }
            item { GradientButton("Novo documento", Icons.Outlined.AutoAwesome, Modifier.fillMaxWidth()) { vm.newDocument() } }
        } else {
            last?.let { item { Text(it, color = p.accent, fontSize = 13.sp) } }
            items(tools, key = { it.title }) { tool ->
                GlassCard(Modifier.fillMaxWidth(), onClick = {
                    val out = tool.run(doc.text)
                    last = when {
                        out == null -> "${tool.title}: o texto não é um JSON válido"
                        out == doc.text -> "${tool.title}: nada para mudar"
                        else -> { vm.replaceText(doc, out); "${tool.title} aplicado. Use Desfazer no Editor para voltar." }
                    }
                }, padding = PaddingValues(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GradientIcon(tool.icon, 38)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tool.title, color = p.text, fontWeight = FontWeight.SemiBold)
                            Text(tool.desc, color = p.muted, fontSize = 12.sp)
                        }
                    }
                }
            }
            item {
                GlassCard(Modifier.fillMaxWidth(), padding = PaddingValues(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GradientIcon(Icons.Outlined.Insights, 38)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("IA online", color = p.text, fontWeight = FontWeight.SemiBold)
                            Text("Resumir, reescrever e traduzir chegam na próxima fase", color = p.muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
