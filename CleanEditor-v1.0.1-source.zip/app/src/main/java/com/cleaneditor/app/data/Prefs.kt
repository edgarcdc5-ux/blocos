package com.cleaneditor.app.data

import android.content.Context
import com.cleaneditor.app.ui.AppTheme
import org.json.JSONArray
import org.json.JSONObject

data class RecentFile(val uri: String, val name: String, val openedAt: Long, val favorite: Boolean = false)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("cleaneditor", Context.MODE_PRIVATE)

    var theme: AppTheme
        get() = runCatching { AppTheme.valueOf(sp.getString("theme", AppTheme.SUNSET.name)!!) }.getOrDefault(AppTheme.SUNSET)
        set(v) = sp.edit().putString("theme", v.name).apply()

    var fontSize: Int
        get() = sp.getInt("fontSize", 15)
        set(v) = sp.edit().putInt("fontSize", v).apply()

    var wrap: Boolean
        get() = sp.getBoolean("wrap", false)
        set(v) = sp.edit().putBoolean("wrap", v).apply()

    var lineNumbers: Boolean
        get() = sp.getBoolean("lineNumbers", true)
        set(v) = sp.edit().putBoolean("lineNumbers", v).apply()

    var userName: String
        get() = sp.getString("userName", "") ?: ""
        set(v) = sp.edit().putString("userName", v).apply()

    fun recents(): List<RecentFile> {
        val arr = JSONArray(sp.getString("recents", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            RecentFile(o.getString("uri"), o.getString("name"), o.getLong("openedAt"), o.optBoolean("favorite"))
        }
    }

    fun saveRecents(list: List<RecentFile>) {
        val arr = JSONArray()
        list.take(50).forEach {
            arr.put(JSONObject().put("uri", it.uri).put("name", it.name).put("openedAt", it.openedAt).put("favorite", it.favorite))
        }
        sp.edit().putString("recents", arr.toString()).apply()
    }
}
