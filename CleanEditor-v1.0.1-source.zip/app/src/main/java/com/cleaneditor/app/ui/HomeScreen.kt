package com.cleaneditor.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.NoteAdd
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.net.Uri
import com.cleaneditor.app.AppViewModel
import com.cleaneditor.app.Tab
import java.util.Calendar

fun relativeTime(t: Long): String {
    val d = (System.currentTimeMillis() - t) / 60000
    return when {
        d < 1 -> "agora"
        d < 60 -> "há $d min"
        d < 1440 -> "há ${d / 60} h"
        else -> "há ${d / 1440} d"
    }
}

@Composable
fun HomeScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    var query by remember { mutableStateOf("") }
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greet = when (hour) { in 5..11 -> "Bom dia"; in 12..17 -> "Boa tarde"; else -> "Boa noite" }
    val todayReminders = vm.reminders.count { r ->
        val c = Calendar.getInstance(); val n = Calendar.getInstance().apply { timeInMillis = r.timeMillis }
        !r.done && c.get(Calendar.YEAR) == n.get(Calendar.YEAR) && c.get(Calendar.DAY_OF_YEAR) == n.get(Calendar.DAY_OF_YEAR)
    }
    val q = query.trim().lowercase()
    val fileHits = if (q.isEmpty()) emptyList() else vm.recents.filter { it.name.lowercase().contains(q) }
    val remHits = if (q.isEmpty()) emptyList() else vm.reminders.filter { it.title.lowercase().contains(q) || it.content.lowercase().contains(q) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 16.dp, bottom = 120.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(greet + if (vm.userName.isNotBlank()) "," else "", color = p.muted, fontSize = 15.sp)
                    Text(vm.userName.ifBlank { "CleanEditor" }, color = p.text, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    "v1.0.1", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(p.surface).padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
        item { SearchField(query, "Buscar em tudo", { query = it }) }

        if (q.isNotEmpty()) {
            item { SectionLabel("Resultados") }
            if (fileHits.isEmpty() && remHits.isEmpty()) item { Text("Nada encontrado para \"$query\"", color = p.muted) }
            items(fileHits, key = { "f" + it.uri }) { f ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { vm.open(Uri.parse(f.uri)) }) {
                    Text(f.name, color = p.text, fontWeight = FontWeight.SemiBold)
                    Text("Arquivo • ${relativeTime(f.openedAt)}", color = p.muted, fontSize = 13.sp)
                }
            }
            items(remHits, key = { "r" + it.id }) { r ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { vm.tab = Tab.LEMBRETES }) {
                    Text(r.title, color = p.text, fontWeight = FontWeight.SemiBold)
                    Text("Lembrete • ${r.category}", color = p.muted, fontSize = 13.sp)
                }
            }
        } else {
            val last = vm.recents.firstOrNull()
            item {
                GradientCard(Modifier.fillMaxWidth(), onClick = {
                    if (last != null) vm.open(Uri.parse(last.uri)) else vm.newDocument()
                }) {
                    Text(if (last != null) "Continue editando" else "Comece a escrever", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(last?.name ?: "Crie seu primeiro documento", color = Color.White.copy(alpha = 0.85f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(14.dp))
                    Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color.White.copy(alpha = 0.3f))) {
                        Box(Modifier.fillMaxWidth(0.62f).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color.White))
                    }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Tile("Editor", "TXT, MD, JSON, CSV", Icons.Outlined.Edit, Modifier.weight(1f)) { vm.newDocument() }
                        Tile("Arquivos", "${vm.recents.size} recentes", Icons.Outlined.Folder, Modifier.weight(1f)) { vm.tab = Tab.ARQUIVOS }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Tile("Lembretes", if (todayReminders > 0) "$todayReminders hoje" else "Nada hoje", Icons.Outlined.NotificationsNone, Modifier.weight(1f)) { vm.tab = Tab.LEMBRETES }
                        Tile("Assistente IA", "Ferramentas de texto", Icons.Outlined.AutoAwesome, Modifier.weight(1f)) { vm.tab = Tab.IA }
                    }
                }
            }
            item { SectionLabel("Recentes") }
            if (vm.recents.isEmpty()) {
                item { EmptyState(Icons.Outlined.NoteAdd, "Nenhum arquivo ainda", "Toque em Editor para criar um documento") }
            }
            items(vm.recents.take(5), key = { it.uri }) { f ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { vm.open(Uri.parse(f.uri)) }, padding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Description, null, tint = p.accent)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, color = p.text, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(relativeTime(f.openedAt), color = p.muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Tile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    GlassCard(modifier.height(132.dp), onClick = onClick) {
        GradientIcon(icon)
        Spacer(Modifier.weight(1f))
        Text(title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
        Text(subtitle, color = p.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
