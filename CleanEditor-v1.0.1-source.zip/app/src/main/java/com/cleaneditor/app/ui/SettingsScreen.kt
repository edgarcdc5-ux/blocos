package com.cleaneditor.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cleaneditor.app.AppViewModel

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp)
    ) {
        item { ScreenTitle("Ajustes") }
        item { SectionLabel("Aparência") }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Tema", color = p.text, fontWeight = FontWeight.SemiBold)
                Text("Sunset é o padrão. O Claro deixa tudo branco e verde.", color = p.muted, fontSize = 12.sp)
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppTheme.entries.forEach { t -> Pill(t.label, vm.theme == t) { vm.setThemeChoice(t) } }
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Seu nome", color = p.text, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(vm.userName, { vm.setName(it) }, singleLine = true, placeholder = { Text("Aparece na saudação do Início") },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        }
        item { SectionLabel("Editor") }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Tamanho da fonte: ${vm.fontSize}", color = p.text, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = vm.fontSize.toFloat(), onValueChange = { vm.setFont(it.toInt()) }, valueRange = 12f..24f, steps = 11,
                    colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent)
                )
            }
        }
        item { ToggleRow("Quebra de linha", "Ajusta linhas longas à largura da tela", vm.wrap) { vm.setWrapChoice(it) } }
        item { ToggleRow("Números de linha", "Mostra a numeração ao lado do texto", vm.lineNumbers) { vm.setLineNumbersChoice(it) } }
        item { SectionLabel("Sobre") }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("CleanEditor 1.0.0", color = p.text, fontWeight = FontWeight.SemiBold)
                Text("Editor de textos, arquivos, lembretes e ferramentas de IA. Seus dados ficam no aparelho.", color = p.muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ToggleRow(title: String, desc: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = p.text, fontWeight = FontWeight.SemiBold)
                Text(desc, color = p.muted, fontSize = 12.sp)
            }
            Switch(value, onChange, colors = SwitchDefaults.colors(checkedTrackColor = p.accent))
        }
    }
}
