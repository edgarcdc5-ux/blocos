package com.cleaneditor.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Redo
import androidx.compose.material.icons.outlined.Undo
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cleaneditor.app.AppViewModel
import com.cleaneditor.app.EditorDoc
import com.cleaneditor.app.Tab

fun formatOf(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
    "md", "markdown" -> "Markdown"
    "json" -> "JSON"
    "csv" -> "CSV"
    "html", "htm" -> "HTML"
    "xml" -> "XML"
    "log" -> "Log"
    "kt", "java", "js", "ts", "py", "brs", "c", "cpp", "css", "sh" -> "Código"
    else -> "Texto"
}

fun wordCount(t: String): Int = t.split(Regex("\\s+")).count { it.isNotBlank() }

private class Highlighter(private val p: Palette, private val format: String) : VisualTransformation {
    private val strRx = Regex("\"(?:[^\"\\\\]|\\\\.)*\"")
    private val numRx = Regex("(?<![\\w.])-?\\d+(?:\\.\\d+)?")
    override fun filter(text: AnnotatedString): TransformedText {
        val src = text.text
        if (src.length > 200_000) return TransformedText(text, OffsetMapping.Identity)
        val out = buildAnnotatedString {
            append(src)
            if (format == "Markdown") {
                var start = 0
                src.split('\n').forEach { line ->
                    val t = line.trimStart()
                    when {
                        t.startsWith("#") -> addStyle(SpanStyle(color = p.codeHeading, fontWeight = FontWeight.Bold), start, start + line.length)
                        t.startsWith("- ") || t.startsWith("* ") || t.matches(Regex("^\\d+\\. .*")) -> {
                            val off = line.length - t.length
                            addStyle(SpanStyle(color = p.codeBullet, fontWeight = FontWeight.Bold), start + off, start + off + 1)
                        }
                        t.startsWith(">") -> addStyle(SpanStyle(color = p.muted), start, start + line.length)
                    }
                    start += line.length + 1
                }
            } else if (format == "JSON" || format == "Código") {
                strRx.findAll(src).forEach { addStyle(SpanStyle(color = p.codeString), it.range.first, it.range.last + 1) }
                numRx.findAll(src).forEach { addStyle(SpanStyle(color = p.codeNumber), it.range.first, it.range.last + 1) }
            }
        }
        return TransformedText(out, OffsetMapping.Identity)
    }
}

@Composable
fun EditorScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    val doc = vm.currentDoc ?: return
    var menu by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var find by remember { mutableStateOf("") }
    var replace by remember { mutableStateOf("") }
    var renaming by remember { mutableStateOf(false) }
    var closeAsk by remember { mutableStateOf<Int?>(null) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) vm.saveAs(doc, uri)
    }
    val format = formatOf(doc.name)
    val highlighter = remember(p, format) { Highlighter(p, format) }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.editorOpen = false }) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Voltar", tint = p.text) }
            Text("Editor", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            Box {
                IconButton({ menu = true }) { Icon(Icons.Outlined.MoreVert, "Mais", tint = p.text) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Novo documento") }, { menu = false; vm.newDocument() })
                    DropdownMenuItem({ Text("Renomear") }, { menu = false; renaming = true }, enabled = doc.uri.startsWith("file:"))
                    DropdownMenuItem({ Text("Exportar cópia…") }, { menu = false; exporter.launch(doc.name) })
                    DropdownMenuItem({ Text("Fechar aba") }, { menu = false; if (doc.dirty) closeAsk = vm.current else vm.closeDoc(vm.current) })
                }
            }
        }
        // Tabs
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            vm.docs.forEachIndexed { i, d ->
                val active = i == vm.current
                val shape = RoundedCornerShape(14.dp)
                Row(
                    Modifier.clip(shape).background(if (active) p.surfaceStrong else p.surface).border(1.dp, if (active) p.accent.copy(alpha = 0.6f) else p.border, shape)
                        .clickable { vm.current = i }.padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text((if (d.dirty) "● " else "") + d.name, color = if (active) p.text else p.muted, fontSize = 13.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 160.dp))
                    IconButton({ if (d.dirty) closeAsk = i else vm.closeDoc(i) }, Modifier.size(28.dp)) {
                        Icon(Icons.Outlined.Close, "Fechar", tint = p.muted, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        // Toolbar
        GlassCard(Modifier.padding(horizontal = 12.dp, vertical = 10.dp).fillMaxWidth(), padding = androidx.compose.foundation.layout.PaddingValues(4.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                IconButton({ vm.undo(doc) }) { Icon(Icons.Outlined.Undo, "Desfazer", tint = p.accent) }
                IconButton({ vm.redo(doc) }) { Icon(Icons.Outlined.Redo, "Refazer", tint = p.accent) }
                IconButton({ searching = !searching }) { Icon(Icons.Outlined.Search, "Buscar", tint = if (searching) p.text else p.accent) }
                IconButton({ vm.wrapSelection(doc, "**", "**") }) {
                    Text("B", color = p.accent, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                }
                IconButton({ vm.linePrefix(doc, "- ") }) {
                    Text("•≡", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                IconButton({ vm.save(doc) }) { Icon(Icons.Outlined.Save, "Salvar", tint = if (doc.dirty) p.accent else p.muted) }
            }
        }
        if (searching) {
            val count = if (find.isEmpty()) 0 else Regex(Regex.escape(find), RegexOption.IGNORE_CASE).findAll(doc.text).count()
            Column(Modifier.padding(horizontal = 12.dp)) {
                SearchField(find, "Buscar no texto", { find = it })
                Spacer(Modifier.size(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SearchField(replace, "Substituir por", { replace = it }, Modifier.weight(1f))
                    TextButton({
                        if (find.isNotEmpty()) vm.replaceText(doc, doc.text.replace(find, replace, ignoreCase = true))
                    }) { Text("Trocar ($count)", color = p.accent) }
                }
            }
        }
        // Text area
        val vScroll = rememberScrollState()
        val hScroll = rememberScrollState()
        val style = TextStyle(color = p.text, fontSize = vm.fontSize.sp, fontFamily = FontFamily.Monospace, lineHeight = (vm.fontSize * 1.5).sp)
        Row(Modifier.weight(1f).fillMaxWidth().verticalScroll(vScroll).padding(horizontal = 8.dp, vertical = 6.dp)) {
            if (vm.lineNumbers && !vm.wrap) {
                val lines = doc.text.count { it == '\n' } + 1
                Text(
                    (1..lines).joinToString("\n"),
                    style = style.copy(color = p.muted.copy(alpha = 0.7f), textAlign = TextAlign.End),
                    modifier = Modifier.padding(end = 10.dp).widthIn(min = 28.dp)
                )
            }
            val fieldMod = if (vm.wrap) Modifier.fillMaxWidth() else Modifier.horizontalScroll(hScroll)
            Box(fieldMod) {
                if (doc.text.isEmpty()) Text("Comece a escrever…", style = style.copy(color = p.muted))
                BasicTextField(
                    value = doc.value,
                    onValueChange = { vm.edit(doc, it) },
                    textStyle = style,
                    cursorBrush = SolidColor(p.accent),
                    visualTransformation = highlighter,
                    modifier = if (vm.wrap) Modifier.fillMaxWidth() else Modifier.widthIn(min = 600.dp)
                )
            }
        }
        // Footer
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("$format • UTF-8 • ${wordCount(doc.text)} palavras", color = p.muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            GradientButton("Melhorar com IA", Icons.Outlined.AutoAwesome) { vm.editorOpen = false; vm.tab = Tab.IA }
        }
    }

    if (renaming) {
        var name by remember { mutableStateOf(doc.name) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Renomear") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton({ vm.renameLocal(doc, name); renaming = false }) { Text("Salvar") } },
            dismissButton = { TextButton({ renaming = false }) { Text("Cancelar") } }
        )
    }
    closeAsk?.let { idx ->
        val d: EditorDoc? = vm.docs.getOrNull(idx)
        AlertDialog(
            onDismissRequest = { closeAsk = null },
            title = { Text("Salvar alterações?") },
            text = { Text("${d?.name ?: "Documento"} tem alterações não salvas.") },
            confirmButton = { TextButton({ d?.let { vm.save(it) }; vm.closeDoc(idx); closeAsk = null }) { Text("Salvar") } },
            dismissButton = { TextButton({ vm.closeDoc(idx); closeAsk = null }) { Text("Descartar", color = Color(0xFFFB7185)) } }
        )
    }
}
