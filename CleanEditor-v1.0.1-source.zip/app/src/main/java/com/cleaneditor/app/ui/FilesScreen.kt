package com.cleaneditor.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cleaneditor.app.AppViewModel

private data class FileRow(val uri: String, val name: String, val time: Long, val local: Boolean, val favorite: Boolean)

@Composable
fun FilesScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Todos") }
    var refresh by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) vm.open(uri, persist = true)
    }

    val rows = remember(refresh, vm.recents.toList(), vm.docs.size) {
        val local = vm.localFiles().map { f ->
            val u = Uri.fromFile(f).toString()
            FileRow(u, f.name, f.lastModified(), true, vm.recents.firstOrNull { it.uri == u }?.favorite == true)
        }
        val ext = vm.recents.filter { r -> local.none { it.uri == r.uri } && !r.uri.startsWith("file:") }
            .map { FileRow(it.uri, it.name, it.openedAt, false, it.favorite) }
        local + ext
    }
    val q = query.trim().lowercase()
    val shown = rows.filter { q.isEmpty() || it.name.lowercase().contains(q) }.filter {
        when (filter) {
            "Meus docs" -> it.local
            "Do aparelho" -> !it.local
            "Favoritos" -> it.favorite
            else -> true
        }
    }.sortedByDescending { it.time }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp)
    ) {
        item { ScreenTitle("Arquivos", "Seus documentos e arquivos do aparelho") }
        item { SearchField(query, "Buscar arquivos", { query = it }) }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Todos", "Meus docs", "Do aparelho", "Favoritos").forEach { Pill(it, filter == it) { filter = it } }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradientButton("Novo", Icons.Outlined.Add, Modifier.weight(1f)) { vm.newDocument(); refresh++ }
                GlassCard(Modifier.weight(1f), onClick = {
                    picker.launch(arrayOf("text/*", "application/json", "application/xml", "application/octet-stream"))
                }, padding = PaddingValues(13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.FolderOpen, null, tint = p.accent)
                        Spacer(Modifier.width(8.dp))
                        Text("Abrir do aparelho", color = p.text, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }
            }
        }
        if (shown.isEmpty()) item { EmptyState(Icons.Outlined.Description, "Nada por aqui", "Crie um documento ou abra um do aparelho") }
        items(shown, key = { it.uri }) { f ->
            GlassCard(Modifier.fillMaxWidth(), onClick = { vm.open(Uri.parse(f.uri)) }, padding = PaddingValues(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GradientIcon(Icons.Outlined.Description, 38)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.name, color = p.text, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text((if (f.local) "Meus docs" else "Aparelho") + " • " + relativeTime(f.time), color = p.muted, fontSize = 12.sp)
                    }
                    IconButton({ vm.toggleFavorite(f.uri, f.name) }) {
                        Icon(if (f.favorite) Icons.Outlined.Star else Icons.Outlined.StarBorder, "Favorito", tint = if (f.favorite) p.medium else p.muted)
                    }
                    IconButton({
                        if (f.local) vm.deleteLocal(java.io.File(Uri.parse(f.uri).path!!)) else vm.removeRecent(f.uri)
                        refresh++
                    }) { Icon(Icons.Outlined.Delete, if (f.local) "Apagar" else "Remover da lista", tint = p.muted) }
                }
            }
        }
    }
}
