# CleanEditor — v1.0.1

Aplicativo Android em Kotlin + Jetpack Compose (Material 3), interface em português do Brasil.

## Funcionalidades existentes

- Início: busca global, recentes e atalhos.
- Editor: abas, desfazer/refazer, busca/substituição, Markdown e JSON, contagem de palavras.
- Arquivos: documentos privados e acesso a documentos do aparelho por SAF, favoritos.
- Lembretes: prioridade, repetição diária, notificações.
- IA: ferramentas de texto **offline**; IA online ainda não foi implementada.
- Ajustes: tema Sunset (padrão) e Claro, fonte, quebra de linha e números de linha.

## Compilação automatizada

Requer Java 17, Android SDK 34 e Gradle 8.9 (instalados pelo GitHub Actions). Não há Gradle Wrapper neste pacote.

1. Coloque **todos os arquivos e pastas**, incluindo `.github/workflows/android-build.yml`, na raiz de um repositório GitHub.
2. Habilite GitHub Actions, se necessário, e acesse **Actions → Compilar APK Android → Run workflow**, ou faça push para `main`.
3. Depois do build bem-sucedido, abra a execução e baixe **CleanEditor-debug-apk** em *Artifacts*.
4. O arquivo `app-debug.apk` será o APK de depuração (não é release assinado para distribuição).

Para compilar localmente num ambiente com SDK e Gradle configurados: `gradle :app:assembleDebug`.

## Histórico de versões

- **1.0.1** (`versionCode 2`): workflow com provisionamento explícito do SDK 34, validação de artefato, ícones de Material com imports não espelhados e exibição de versão atualizada.
- **1.0.0** (`versionCode 1`): código-fonte inicial, ainda sem compilação confirmada.

## Estado dos testes

O código inicial da v1.0.0 não havia sido compilado. Esta v1.0.1 passou por revisão estática, mas **o build só estará confirmado quando o GitHub Actions concluir com sucesso**. Não foram feitos testes em aparelho.

## Próximas entregas

1. Confirmar compilação no GitHub Actions e corrigir eventuais erros apontados pelo log.
2. Revisar fechamento de abas, histórico de edição, SAF, renomeação, favoritos e alarmes exatos.
3. Realce HTML/CSV/log e leitura renderizada de Markdown.
4. IA online opcional, chave protegida, prévia antes de aplicar e desfazer.
